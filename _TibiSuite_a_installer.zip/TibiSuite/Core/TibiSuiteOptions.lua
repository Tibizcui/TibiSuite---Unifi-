-- ================================================================
-- TibiSuiteOptions v4.0
-- Auteur : Tibiscui - Kirin Tor
-- Role   : Panneau « Modules » de la suite. Une case a cocher par
--          module connu (meme non charge). Cocher = charge le module
--          immediatement (LoadOnDemand a chaud). Decocher = le module
--          ne sera plus charge au prochain /reload.
--          Construit sur le socle commun (TibiMidnight.CreateOptionsPanel).
-- Ce fichier ne declare aucune SavedVariables : l'etat vit dans
-- TibiSuiteDB.enabledModules, gere par le core (TibiSuite.SetModuleEnabled).
-- ================================================================

local ACCENT_SUITE = { 0.58, 0.502, 1.00 }   -- lavande : couleur d'identite de la suite
local LOGO         = "Interface\\AddOns\\TibiSuite\\medias\\TibiSuite"

-- Presentation de la suite (installateur + panneau des modules).
local INTRO = "TibiSuite reunit tous tes trackers Tibiscui sous un seul bouton de minicarte et une barre d'onglets. Tu actives seulement les modules voulus : les autres ne sont pas charges et ne consomment aucune memoire."

-- Resume court par module (repris des descriptions officielles de chaque toc).
local DESC = {
  Daily   = "Quetes quotidiennes et hebdomadaires (Midnight, TWW), cochees automatiquement selon ton historique.",
  Dgn     = "Compteur d'entrees d'instances : donjons, raids, gouffres, Torghast, toutes extensions.",
  Leg     = "Suivi des objets legendaires par extension : statut, quetes et composants, sur tout le compte.",
  Rep     = "Reputations et Renom de Vanilla a Midnight : groupes pliables, quetes, suivi auto par zone.",
  Lvl     = "Historique des sessions de leveling et de farm, avec statistiques.",
  Weekly  = "Tableau de bord hebdomadaire : ce qu'il reste a faire pour maximiser tes recompenses.",
  MiniHub = "Regroupe les boutons de la minicarte dans un conteneur unique et retractable.",
  XPBar   = "Barre d'XP avancee : niveau, XP, repos, quetes et statistiques de session.",
  Lair    = "Audit de groupe et pertinence des recompenses pour les Repaires.",
  Skill   = "Progression des metiers par extension (actuel / max + %), pour tous tes personnages.",
}

local panel   -- construit une seule fois (paresseux)

-- Convertit r,g,b [0-1] en code couleur WoW pour teinter le libelle.
local function Hex(c)
  return string.format("|cFF%02X%02X%02X",
    math.floor(c.r * 255 + 0.5), math.floor(c.g * 255 + 0.5), math.floor(c.b * 255 + 0.5))
end

local function Build()
  local UI = _G.TibiMidnight
  if not UI or not UI.CreateOptionsPanel then return nil end
  if panel then return panel end

  panel = UI.CreateOptionsPanel({
    name  = "TibiSuiteModulesPanel",
    title = "|cFF9480FFTibiSuite|r  Modules",
    accent = ACCENT_SUITE,
    logo  = LOGO,
  })

  panel:Section("Modules a charger")
  panel:Note("Cochez les modules que vous voulez. Cocher un module le charge tout de suite. Decocher prend effet au prochain /reload (un module ne peut pas etre decharge a chaud).")

  local catalog = (TibiSuite.GetCatalog and TibiSuite.GetCatalog()) or {}
  for _, mod in ipairs(catalog) do
    local key     = mod.key
    local present = TibiSuite.ModuleExists and TibiSuite.ModuleExists(mod.addonName)
    local label   = Hex(mod.col) .. (mod.addonName or mod.label) .. "|r"
    if not present then
      label = label .. "  |cFF808080(absent)|r"
    end
    panel:Check(
      label,
      function() return TibiSuite.IsModuleEnabled and TibiSuite.IsModuleEnabled(key) end,
      function(v) if TibiSuite.SetModuleEnabled then TibiSuite.SetModuleEnabled(key, v) end end,
      present and ("Charger / decharger " .. mod.addonName)
              or (mod.addonName .. " n'est pas installe (dossier absent).")
    )
  end

  panel:Section("Astuce")
  panel:Note("Un module decoche ne consomme aucune memoire : ses fichiers de donnees ne sont meme pas lus. Seul le core reste toujours charge.")

  return panel
end

-- API publique : ouvrir / fermer le panneau des modules.
function TibiSuite.OpenModulePanel()
  local p = Build()
  if p then p:Toggle() end
end

-- ================================================================
-- INSTALLATEUR PREMIER LANCEMENT
-- ----------------------------------------------------------------
-- Au tout premier login (TibiSuiteDB.setupDone absent), on presente les
-- modules DETECTES sur le disque par lots de 3 cartes, chacune avec sa case
-- "Activer". Terminer applique les choix (cocher = charge le module) et pose
-- le drapeau setupDone. Fermer la fenetre = terminer avec la selection en
-- cours (jamais d'etat bloque). Tout est deja coche par defaut : valider sans
-- rien changer active tous les modules presents, comportement non destructif.
-- ================================================================
local wizard

local function BuildWizard()
  local UI = _G.TibiMidnight
  if not UI then return nil end
  if wizard then return wizard end

  local f = CreateFrame("Frame", "TibiSuiteSetupWizard", UIParent, "BackdropTemplate")
  f:SetSize(400, 476)
  f:SetPoint("CENTER", 0, 40)
  f:SetFrameStrata("FULLSCREEN_DIALOG")
  f:SetToplevel(true)
  f:EnableMouse(true)
  f:SetMovable(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
  UI.SkinFrame(f, ACCENT_SUITE, UI.C.PANEL)
  UI.AddHeaderLogo(f, LOGO)

  local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  title:SetPoint("TOP", 0, -12)
  title:SetText("|cFF9480FFBienvenue dans TibiSuite|r")

  -- Presentation de la suite (ce que c'est).
  local intro = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  intro:SetPoint("TOP", title, "BOTTOM", 0, -6)
  intro:SetWidth(366); intro:SetJustifyH("CENTER")
  intro:SetText(INTRO)

  -- Consigne.
  local hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  hint:SetPoint("TOP", intro, "BOTTOM", 0, -6)
  hint:SetWidth(366); hint:SetJustifyH("CENTER")
  hint:SetText("Coche les modules a activer. Tu pourras revenir sur ton choix a tout moment avec /ts modules.")

  local cards = {}
  for i = 1, 3 do
    local card = CreateFrame("Frame", nil, f, "BackdropTemplate")
    card:SetSize(364, 84)
    card:SetPoint("TOP", f, "TOP", 0, -104 - (i - 1) * 92)
    card:SetBackdrop(UI.FlatBackdrop())
    local cb = CreateFrame("CheckButton", nil, card, "UICheckButtonTemplate")
    cb:SetSize(28, 28); cb:SetPoint("TOPLEFT", 8, -8)
    local name = card:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    name:SetPoint("TOPLEFT", cb, "TOPRIGHT", 8, -3)
    local desc = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    desc:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 0, -4)
    desc:SetPoint("RIGHT", card, "RIGHT", -10, 0)
    desc:SetJustifyH("LEFT"); desc:SetJustifyV("TOP")
    cards[i] = { frame = card, cb = cb, name = name, desc = desc }
  end

  local pageFS = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  pageFS:SetPoint("BOTTOM", 0, 42)

  local prevB = UI.MakeButton(f, 90, 24, "Precedent"); prevB:SetPoint("BOTTOMLEFT", 16, 12)
  local nextB = UI.MakeButton(f, 90, 24, "Suivant");   nextB:SetPoint("BOTTOMRIGHT", -16, 12)
  local doneB = UI.MakeButton(f, 120, 24, "")
  doneB:SetPoint("BOTTOM", 0, 12)
  doneB._label:SetText(UI.Hex(ACCENT_SUITE[1], ACCENT_SUITE[2], ACCENT_SUITE[3]) .. "Terminer|r")

  wizard = { frame = f, cards = cards, page = 1, present = {}, choice = {},
             pageFS = pageFS, prevB = prevB, nextB = nextB }

  local function pages() return math.max(1, math.ceil(#wizard.present / 3)) end

  local function renderPage()
    local np = pages()
    if wizard.page > np then wizard.page = np end
    if wizard.page < 1 then wizard.page = 1 end
    for i = 1, 3 do
      local idx = (wizard.page - 1) * 3 + i
      local mod = wizard.present[idx]
      local card = wizard.cards[i]
      if mod then
        local c = mod.col
        card.frame:Show()
        card.frame:SetBackdropColor(c.r * 0.10, c.g * 0.10, c.b * 0.10, 0.9)
        card.frame:SetBackdropBorderColor(c.r, c.g, c.b, 0.85)
        card.name:SetText(Hex(c) .. (mod.label or mod.addonName) .. "|r")
        card.desc:SetText("|cFFB8B8B8" .. (DESC[mod.key] or mod.addonName or "") .. "|r")
        card.cb:SetChecked(wizard.choice[mod.key] and true or false)
        card.cb:SetScript("OnClick", function(s) wizard.choice[mod.key] = s:GetChecked() and true or nil end)
      else
        card.frame:Hide()
      end
    end
    wizard.pageFS:SetText("Page " .. wizard.page .. " / " .. np
      .. "   (" .. #wizard.present .. " modules detectes)")
    wizard.prevB:SetShown(wizard.page > 1)
    wizard.nextB:SetShown(wizard.page < np)
  end
  wizard.renderPage = renderPage

  prevB:SetScript("OnClick", function() wizard.page = wizard.page - 1; renderPage() end)
  nextB:SetScript("OnClick", function() wizard.page = wizard.page + 1; renderPage() end)

  local function finish()
    for _, mod in ipairs(wizard.present) do
      if TibiSuite.SetModuleEnabled then
        TibiSuite.SetModuleEnabled(mod.key, wizard.choice[mod.key] and true or false)
      end
    end
    TibiSuiteDB.setupDone = true
    f:Hide()
    print("|cFF9480FFTibiSuite|r : installation terminee. |cFFFFD700/ts modules|r pour ajuster plus tard.")
  end
  doneB:SetScript("OnClick", finish)

  local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)
  close:SetScript("OnClick", finish)   -- fermer = terminer, jamais d'etat bloque

  return wizard
end

-- Appele par le core au tout premier login (setupDone absent).
function TibiSuite.RunFirstSetup()
  local catalog = (TibiSuite.GetCatalog and TibiSuite.GetCatalog()) or {}
  local w = BuildWizard()
  if not w then
    -- Socle absent : repli non destructif (activer tout ce qui est present).
    for _, mod in ipairs(catalog) do
      if TibiSuite.ModuleExists and TibiSuite.ModuleExists(mod.addonName)
         and TibiSuite.SetModuleEnabled then
        TibiSuite.SetModuleEnabled(mod.key, true)
      end
    end
    if TibiSuiteDB then TibiSuiteDB.setupDone = true end
    return
  end
  -- Modules presents seulement, tous coches par defaut.
  w.present, w.choice = {}, {}
  for _, mod in ipairs(catalog) do
    if TibiSuite.ModuleExists and TibiSuite.ModuleExists(mod.addonName) then
      w.present[#w.present + 1] = mod
      w.choice[mod.key] = true
    end
  end
  w.page = 1
  w.renderPage()
  w.frame:Show()
end
